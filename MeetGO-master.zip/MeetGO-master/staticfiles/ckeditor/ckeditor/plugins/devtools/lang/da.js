﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","da",{title:"Information på elementet",dialogName:"Dialogboks",tabName:"Tab beskrivelse",elementId:"ID på element",elementType:"Type af element"});